import { ModuleWithProviders } from '@angular/core';
import{RouterModule,Routes, Router } from '@angular/router';

import{ HomeComponent } from './home/home.component';
import{ProductComponent} from './product/product.component';
import { AddEditComponent } from './add-edit/add-edit.component';
import { LoginComponent } from './login/login.component';
import { AuthGuard } from 'src/app/login/AuthGuard';
import { AddSupplierComponent } from './add-supplier/add-supplier.component';
import { VINSearchComponent } from './vin-search/vin-search.component';
import { TrademanagerComponent } from './trade-manager/trade-manager.component';
import { DealerSearchComponent } from './dealer-search/dealer-search.component';
import { ReportsComponent } from './reports/reports.component';
import { FileProcessComponent } from './file-process/file-process.component';
import { UserListComponent } from './admin/list-user/list-user.component';
import { CreateUserComponent } from './admin/add-user/add-user.component';
import { RemoveUserComponent } from './admin/remove-user/remove-user.component';
import { DetailUserComponent } from './admin/detail-user/detail-user.component';
import { PrefrencesComponent } from './prefrences/prefrences.component';



export const routes : Routes = [
    {path: 'vinsearch',  component:VINSearchComponent},
    {path:"inventories",component:ProductComponent},
    {path:"",redirectTo:"vinsearch",pathMatch:"full"},
    {path:'users',component:UserListComponent},
    {path:'prefrences',component:PrefrencesComponent},
    {path:'users/list',component:UserListComponent},
    { path: 'users/add', component: CreateUserComponent },
    { path: 'users/add/:searchKey', component: CreateUserComponent },
    {path:'users/remove/:id',component:RemoveUserComponent},
    {path:'users/details/:id',component:DetailUserComponent},
    {path:'vinsearch',component:VINSearchComponent},
    {path:'trademanager',component:TrademanagerComponent},
    {path:'dealersearch',component:DealerSearchComponent},
    {path:'reports',component:ReportsComponent},
    {path:'fileprocess',component:FileProcessComponent},
    {path:"inventory", component:AddEditComponent,canActivate:[AuthGuard]},
    {path:"inventory/:productId", component:AddEditComponent,canActivate:[AuthGuard]},
    {path:"supplier", component:AddSupplierComponent,canActivate:[AuthGuard]},
];

export const AppRouting : ModuleWithProviders = RouterModule.forRoot(routes);
