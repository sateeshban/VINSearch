import { Component, OnInit, ViewChild } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';

import { Supplier } from '../models/supplier';
import { InventoryService } from '../services/product.service';
import { Inventory } from '../models/Inventory';
import { NgForm } from '@angular/forms';
import { LoginService } from '../login/login.service';

@Component({
  selector: 'app-add-edit',
  templateUrl: './add-edit.component.html',
  styleUrls: ['./add-edit.component.css']
})
export class AddEditComponent implements OnInit {

  @ViewChild('f') ngForm : any;
  supplierList : Supplier [];
  inventory : Inventory;
  productId : number = 0;
  isProductInserted : boolean = null;
  isProductUpdated : boolean = null;
  isInventoryExists : boolean = false;
  isProductNameExists : boolean = false;
  isEditable : boolean = false;
  constructor(private inventoryService : InventoryService, private router:Router,private activatedRoute: ActivatedRoute, private loginService: LoginService) { 
     this.inventory = new Inventory();
    this.productId = this.activatedRoute.snapshot.params["productId"];
  }

  
  ngOnInit() {
    this.getSuppliers();
    if(this.productId > 0){
    this.getProductDetailsById(this.productId);
    }else{
      this.productId = 0;
    }
  }

  getSuppliers(): void{
    this.inventoryService.getSuppliers().subscribe((response:any)=>{
      if(response.length > 0){
        debugger;
        this.supplierList = response;
      }
    });

  }

  CheckProductExists(product) : void {
    debugger;
   if(product != null && product != ""){ 
    this.inventoryService.CheckProductExists(product).subscribe((response:any)=>{
      if(response!=null){
        this.isProductNameExists = response.IsProductNameExists;
      }
    });
  }
}

  onSupplierChange($event) : void{
    this.inventory.SupplierName = $event.target.options[$event.target.selectedIndex].text;
  }

  onSubmit() : void{
   debugger;
   this.inventory.ProductId = this.inventory.ProductId == null ? 0 : this.inventory.ProductId;
   this.inventory.TotalCost = this.inventory.TotalCost == null ? 0 : this.inventory.TotalCost;
    let modeldata =this.inventory;
    modeldata.TotalCost = (this.inventory.Quantity * this.inventory.UnitPrice);
    if(this.productId == 0){
         this.inventoryService.saveInventory(modeldata).subscribe((response:any)=> {
           if(response!=null && response.id > 0){
             this.isProductInserted= true;
             this.router.navigate(["inventories"]);
           }else{
             this.isProductInserted = false;
           }
        });
     }else{
      this.inventoryService.updateInventory(modeldata).subscribe((response:any)=> {
      if(response!=null && response.IsProductUpdated ){
        this.isProductUpdated = true;
        this.router.navigate(["inventories"]);
      }else{
        this.isProductUpdated = false;
      }
     });
     }
  }

  getProductDetailsById(productId:number) : void{
    this.inventoryService.getProductDetailsById(productId).subscribe((response:any)=> {
     this.inventory = response;
   });
  }

  backToList():void{
    this.router.navigate(["inventories"]);
  }
  clearForm(productForm):void{
      //productForm.resetForm();
      this.backToList();
  }
  SignOut() {
    this.loginService.authSignOut();
  }

}
