import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { LoginService } from '../login/login.service';
import { LoginComponent } from '../login/login.component';
import { CommonModule } from '@angular/common';


@NgModule({
  imports: [
    HttpModule,
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    RouterModule.forChild([ 
      {path:'',component:LoginComponent}
    ])
  ],
  declarations: [LoginComponent],
  providers:[LoginService],
  
})
export class LoginModule { }
