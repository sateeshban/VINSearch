import { Injectable } from "@angular/core";
import{Http,Headers,Request,Response,RequestOptions } from '@angular/http';
import  { observable, Observable, BehaviorSubject } from 'rxjs';
import { map, tap } from 'rxjs/operators';
import { TokenModel } from "../models/tokenModel";
import { environment   } from '../../environments/environment';
import { AccountModel } from "../models/accountModel";
import { BaseService } from "../services/base.service";
import { Router } from "@angular/router";


@Injectable()
export class LoginService extends BaseService{

        isAuthenticated  = false;
        private _loggedIn = new BehaviorSubject<boolean>(false);
        
        get IsUserLoggedIn() {
            return this._loggedIn.asObservable();
          }
        
        constructor(public _http : Http,public router: Router) {
            super(_http,router)
        }

        validateUser(username:string,password:string):any{
            const credentials= 'username='+username+'&password='+password+"&grant_type=password";
            let httpHeaders = new Headers({
                'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8',
                'Access-Control-Allow-Origin': '*',
                'Accept': 'application/json',
                'Access-Control-Allow-Methods': '*' 
            });
            this._loggedIn.next(true);
            let options = new RequestOptions({ headers: httpHeaders });
            return this._http.post(`${environment.api}token`,  credentials, { headers: httpHeaders })
            .pipe(
                map(data => data.json())
            );
            
        }

        getAccountDetails(accountName: string): Observable<AccountModel> {
            return this.get(`${environment.api_path}`+"account/"+accountName)
                .pipe(
                    map(data => data)
                );
        }
        
    authSignOut() {
        debugger;
        localStorage.removeItem('token');
        localStorage.setItem('isAuth', 'false');
        this._loggedIn.next(false);
        this.router.navigateByUrl('/');

        history.pushState(null, null, 'nopage');
        window.addEventListener('popstate', function (event) {
            history.pushState(null, null, 'nopage');
        }); // back button disable [ended]
    }
}