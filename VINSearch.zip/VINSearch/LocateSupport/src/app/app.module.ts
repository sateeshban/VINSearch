import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { FormsModule } from '@angular/forms';

import { NgbModule,NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import{ ModalService } from '../app/services/ModalService';
import { InventoryService } from '../app/services/product.service';
import { AuthGuard } from './login/AuthGuard';
import { AppRouting } from './app.routing';
import { LoginModule } from './login/login.module';
import { AngularDualListBoxModule } from 'angular-dual-listbox'
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { CommonModalComponent } from '../app/common/modal/common.modal.component';
import { AddSupplierComponent } from './add-supplier/add-supplier.component';
import { AddEditComponent } from './add-edit/add-edit.component';
import { ProductComponent } from './product/product.component';
import { SidebarDirective } from './directives/sidebar.directive';
import { VINSearchComponent } from './vin-search/vin-search.component';
import { TrademanagerComponent } from './trade-manager/trade-manager.component';
import { DealerSearchComponent } from './dealer-search/dealer-search.component';
import { FileProcessComponent } from './file-process/file-process.component';
import { ReportsComponent } from './reports/reports.component';
import { PrefrencesComponent } from './prefrences/prefrences.component';
import { UserListComponent } from './admin/list-user/list-user.component';
import { CreateUserComponent } from './admin/add-user/add-user.component';
import { RemoveUserComponent } from './admin/remove-user/remove-user.component';
import { DetailUserComponent } from './admin/detail-user/detail-user.component';
import { AdminService } from './services/admin.service';
import {HttpClientModule} from '@angular/common/http';
import { HttpService } from './services/http.service';
import { PreferenceService } from './services/preference.service';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    CommonModalComponent,
    ProductComponent,
    AddEditComponent,
    AddSupplierComponent,
    SidebarDirective,
    VINSearchComponent,
    TrademanagerComponent,
    ReportsComponent,
    DealerSearchComponent,
    FileProcessComponent,
    PrefrencesComponent,
    UserListComponent,
    CreateUserComponent,
    RemoveUserComponent,
    DetailUserComponent
  ],
  imports: [
    BrowserModule,
    AngularDualListBoxModule,
    HttpClientModule,
    HttpModule,
    FormsModule,
    LoginModule,
    AppRouting,
    NgbModule.forRoot()
  ],
  entryComponents: [CommonModalComponent
  ],
  providers: [InventoryService, ModalService, NgbActiveModal, AuthGuard,AdminService,HttpService,PreferenceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
