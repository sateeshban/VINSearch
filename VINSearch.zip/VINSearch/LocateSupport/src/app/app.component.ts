import { Component, Input, OnInit } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Router } from '@angular/router';
import { LoginService } from '../app/login/login.service';
//'' '..\login\login.service.ts'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'app';
  loader = false;
  showSidebar = false;
  welcomeName = '';
@Input() isLoggedIn: boolean = false;
private loggedIn = new BehaviorSubject<boolean>(false);

constructor(private router: Router, private loginService: LoginService){

}

ngOnInit(): void {
  // Setup a subscription so our variable will know the latest status of login
  // this.loginService.isLoggedIn().subscribe(status => this.isUserLoggedIn = status);
  // this.loginService.isAuthenticated;
}

  get isAuth(): boolean {
    return localStorage.getItem('isAuth') === 'true' ? true : false;
  }

  get welcomeUser(): string {
    return localStorage.getItem('welcomeUser');
  }

  openSideBar () {
    this.showSidebar = true;
  }

  SignOut() {
    debugger;
    this.loginService.authSignOut();
    // localStorage.removeItem('token');
    // localStorage.setItem('isAuth', 'false');
    // this.router.navigateByUrl('/');

    // history.pushState(null, null, 'nopage');
    // window.addEventListener('popstate', function (event) {
    //   history.pushState(null, null, 'nopage');
    // }); // back button disable [ended]
  }
}