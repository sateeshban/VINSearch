import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-list',
  templateUrl: './list-user.component.html'
})
export class UserListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
