import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router'
import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { DialogModel } from '../../models/dialogModel';
import { DataTableResponse } from '../../models/dataTableResponse';
import { TokenService } from '../../services/add-user.service';
import { Http } from '@angular/http';
import { BaseService } from '../../services/base.service';
import { CommonModalComponent } from '../../common/modal/common.modal.component';
import { ModalService } from '../../services/ModalService';
import { Observable, from } from 'rxjs';
import { AdminService } from '../../services/admin.service';
import { user } from '../../models/user';
import { HttpService } from '../../services/http.service';


@Component({
  selector: 'app-user-add',
  templateUrl: './add-user.component.html',
  providers: [TokenService, HttpService]
})
export class CreateUserComponent implements OnInit {
  source: Array<string>
  confirmed: Array<string>
  isHavingEmptyRecords: boolean = false;
  user: user = new user();
  ConfirmMessage:string;
  constructor(
    private modalService: ModalService,
    private router: Router,
    private tokenService: TokenService,
    private currentModal: NgbActiveModal,
    private route: ActivatedRoute,
    private adminService: AdminService,
    private httpservice: HttpService
  ) { }

  ngOnInit() {
    this.source = this.httpservice.getTokens().subscribe((resp: any) => {
      this.source = resp;
    })
    this.confirmed=[];
    let removeUserId = this.route.snapshot.params['searchKey'];
    if (removeUserId) {
       this.user = this.httpservice.getUser(removeUserId).subscribe((resp: any) => {
        this.user.firstname = resp.data.FirstName;
        this.user.lastname = resp.data.LastName;
        this.user.department = resp.data.Department;
        this.user.company = resp.data.Company;
        this.user.cdsid = resp.data.CDSID;
        this.confirmed = resp.data.TokenList;
        this.user.removeId=true;
      })

    }
    else{
      this.user.removeId=false;
    }

  }
 addUser() {
      debugger;
      this.user.tokens=this.confirmed;
       this.httpservice.addUser(this.user).subscribe((resp: any) => {
      
       this.ConfirmMessage=resp;
      },
      err => {
        this.ConfirmMessage=err[0];
      })
      
    }
    updateUser() {
      debugger;
      this.user.tokens=this.confirmed;
       this.httpservice.updateUser(this.user).subscribe((resp: any) => {
      
       this.ConfirmMessage=resp;
      },
      err => {
        this.ConfirmMessage=err[0];
      })
      
    }

}





