import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vin-search',
  templateUrl: './vin-search.component.html'
})
export class VINSearchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
