import { Component, ViewEncapsulation, Input,Output,EventEmitter, Injector, PLATFORM_ID, Inject } from '@angular/core';
import { NgbModal,NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { NgbModalBackdrop } from '@ng-bootstrap/ng-bootstrap/modal/modal-backdrop';

import { isPlatformBrowser } from '@angular/common';

@Component({
  selector: 'ngbd-modal-options',
  templateUrl: './common.modal.component.html',
  encapsulation: ViewEncapsulation.None,
  styles: [`
    .dark-modal .modal-content {
      background-color: #292b2c;
      color: white;
    }
    .dark-modal .close {
      color: white;
    }
    .light-blue-backdrop {
      background-color: #5cb3fd;
    }
  `]
})
export class CommonModalComponent {
  closeResult: string;
  @Input() productName;
  @Input() productId;

  @Output()
  delete:EventEmitter<number> = new EventEmitter();

  private modalService: NgbModal;

  constructor(@Inject(PLATFORM_ID) private platformId:object,private injector : Injector,public currentModal:NgbActiveModal) {
      if(isPlatformBrowser(this.platformId)){
          this.modalService = this.injector.get(NgbModal);
      }
  }

  ConfirmToDelete() : void {
    this.delete.emit(this.productId);
  }

}