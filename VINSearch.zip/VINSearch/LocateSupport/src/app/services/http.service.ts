import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Subscribable } from 'rxjs';
import { user } from '../models/user';




@Injectable({
    providedIn: 'root'
})
export class HttpService {

    readonly baseURL = 'http://localhost:60750/api'
    urlString: any;

    constructor(private httpClient: HttpClient) {
    }

    getUser(userId): any {
        return this.httpClient.get(`${this.baseURL}/admin/${userId}`);
    }
    getTokens(): any {
        return this.httpClient.get(`${this.baseURL}/admin/GetTokens`);
    }
      addUser(user: any) {
          debugger;
        const data = {
            FirstName: user.firstname,
            LastName: user.lastname,
            TokenList: user.tokens,            
            Department: user.department,
            CDSID: user.cdsid,
            Company:user.company
            
        };
        const userModel = JSON.stringify(data);
        const h = new HttpHeaders({'Content-Type': 'application/json'});
        return this.httpClient.post<user>(`${this.baseURL}/admin/AddUser`, userModel, {headers: h});
    } 
    updateUser(user: any) {
        debugger;
      const data = {
          FirstName: user.firstname,
          LastName: user.lastname,
          TokenList: user.tokens,            
          Department: user.department,
          CDSID: user.cdsid,
          Company:user.company
          
      };
      const userModel = JSON.stringify(data);
      const h = new HttpHeaders({'Content-Type': 'application/json'});
      return this.httpClient.post<user>(`${this.baseURL}/admin/UpdateUser`, userModel, {headers: h});
  } 

}

