import { Observable } from 'rxjs';
import { Injectable, Output } from '@angular/core';
import {CommonModalComponent} from '../common/modal/common.modal.component';
import { DialogModel } from '../models/dialogModel';
import { NgbModal, NgbActiveModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';

@Injectable()
export class ModalService {

    result: any;

    constructor(private modalService: NgbModal) { }

    confirmDialog(dialogModel : DialogModel)
        : Observable<boolean> | Promise<boolean> {
        const modalRef = this.modalService.open(CommonModalComponent, { size: 'lg' });
        modalRef.componentInstance.title = dialogModel.title;
        modalRef.componentInstance.body = dialogModel.body;
        modalRef.componentInstance.isCancelEnabled = dialogModel.isCancelEnabled;
        modalRef.componentInstance.btnOkText = dialogModel.btnOkText;
        modalRef.componentInstance.btnCancelText = dialogModel.btnCancelText;
        return modalRef.result;
    }
   
   
}
