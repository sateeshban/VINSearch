import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Router } from '@angular/router';
import { Observable,throwError, timer, } from 'rxjs'
import { map,catchError, retryWhen } from 'rxjs/operators'



export abstract class BaseService {

    options: RequestOptions;
    headers = new Headers();

    constructor(public httpClient: Http, public router: Router) { 

    }

    /**
     *This method is used to convert incoming data into JSON format
     *
     *@private
     *@param {Response} res
     *@returns
     *
     *@memberOf BaseService
     */
    extractData(res: Response) {
        debugger;
        if (res == null || res === undefined) {
            return {};
        }
        const body = res.json();
        return body || {};
    }

    /**
     *Centralize method to handle Error thrown by services.
     *
     *@private
     *@param {(Response | any)} error
     *@returns
     *
     *@memberOf BaseService
     */
    handleError(error: Response | any):Observable<Response> {
        return Observable.throw(error);
    }

    /**
     * This function is used to retry api call for specific error code.
     *
     * @param {(Response | any)} errors 
     * @returns 
     * @memberof BaseService
     */
    handleRetry(errors: Response | any) {
       
    }

    /**
     *Centralize method to throw error
     *
     *@private
     *@param {string} errMsg
     *@returns {Observable<any>}
     *
     *@memberOf BaseService
     */
    throwError(errMsg: string): Observable<any> {
        return Observable.throw(errMsg);
    }

    /**
     *
     *
     *@param {string} url
     *@returns {Observable<any>}
     *
     *@memberof BaseService
     */
    get(url: string): Observable<any> {
        const options = this.GetAuthHeaders();
    return this.httpClient.get(url,options).pipe(map(this.extractData),catchError(this.handleError))
      
    }

    /**
     *
     *
     *@param {string} url
     *@param {*} body
     *@returns {Observable<any>}
     *
     *@memberof BaseService
     */
    post(url: string, body: any): Observable<any> {
        const options = this.GetAuthHeaders();
        let data = JSON.stringify(body)
      return this.httpClient.post(url,data,options).pipe(map(this.extractData),catchError(this.handleError));
    }


    /**
     *
     *
     *@param {string} url
     *@param {*} data
     *@returns
     *
     *@memberof BaseService
     */
    put(url: string, data: any): Observable<any> {
        const options = this.GetAuthHeaders();
       // headers.append('Content-Type', 'application/json');

        return this.httpClient
        .put(url, JSON.stringify(data),options ).pipe(map(this.extractData),catchError(this.handleError));
    
    }

    /**
         *
         *
         *@param {string} url
         *@returns
         *
         *@memberof BaseService
         */
    delete(url: string): Observable<any> {
        const options = this.GetAuthHeaders();
     return this.httpClient
.delete(url, options).pipe(map(this.extractData),catchError(this.handleError));

    }

    /**
     * 
     * 
     * @returns {Headers} 
     * 
     * @memberof BaseService
     */
    GetAuthHeaders(): RequestOptions {
        const headers = new Headers();
    let token = localStorage.getItem("token");
    headers.append('Access-Control-Allow-Origin', '*');
    headers.append('Access-Control-Allow-Methods', 'GET, POST, PATCH, PUT, DELETE, OPTIONS');
    headers.append('Access-Control-Allow-Headers', 'Origin, Content-Type, X-Auth-Token');
    headers.append('Access-Control-Allow-Credentials', 'true');
    //The following headers are required for IE support
    headers.append('Pragma', 'no-cache');
    headers.append('Cache-Control', 'no-cache');
    headers.append('If-Modified-Since', new Date().toUTCString());
    headers.append('Content-Type', 'application/json');
    headers.append('Accept', 'application/json');
    headers.append('authorization',"bearer "+token);

   let options = new RequestOptions({ headers: headers });
        return options;
    }
}
