import { Http,Headers,Request,Response,RequestOptions } from '@angular/http'
import { BaseService } from './base.service';
import { Router } from '@angular/router';
import { Injectable } from '@angular/core';
import { Inventory } from '../models/inventory';
import { Observable } from 'rxjs';
import{ map } from 'rxjs/operators';
import { environment   } from '../../environments/environment'
import { Supplier } from '../models/supplier';

@Injectable()
export class InventoryService extends BaseService {
    /**
     *
     */
    constructor(private _http: Http, router : Router) {
        super(_http,router);
    }
    // public getInventories() : Observable<any>{
    //     debugger;
    //     return this.get(environment.api_path+"products")
    //     .pipe(map((response)=> {
    //         debugger;
    //           return response;
    //     }));
    // }
    public getInventories(isActives: boolean) : Observable<any>{
        debugger;
        return this.get(environment.api_path+"productlist/"+isActives)
        .pipe(map((response)=> {
              return response;
        }));
    }
    

    public getSuppliers() : Observable<any>{
        return this.get(environment.api_path+"suppliers")
        .pipe(map((response)=> {
            debugger;
              return response;
        }));
    }


    public saveInventory(inventory: Inventory) : Observable<any>{
        return this.post(environment.api_path+"add",inventory)
        .pipe(map((response)=>{
            return response;
        }));
    }

    public AddNewSupplier(supplierMdl: Supplier) : Observable<any>{debugger;
        return this.post(environment.api_path+"suppliers",supplierMdl)
        .pipe(map((response)=>{
            return response;
        }));
    }

    public CheckSupplierExists(suppliername: string):Observable<boolean>{
        return this.get(environment.api_path+"suppliers/"+suppliername).pipe(
            map(res=>{
                return res;
            })
        );
    }

    public updateInventory(inventory: Inventory) : Observable<any>{
        return this.put(environment.api_path+"update",inventory)
        .pipe(map((response)=>{
            return response;
        }));
    }

    public deleteInventory(product: number) : Observable<any>{debugger;
        return this.delete(environment.api_path+""+product)
        .pipe(map((response)=>{
            return response;
        }));
        // return this.delete(environment.api_path+"delete", product)
        // .pipe(map((response)=>{
        //     return response;
        // }));
    }

    public getProductDetailsById(productId: number) : Observable<any>{
        return this.get(environment.api_path+"product/"+productId)
        .pipe(map((response)=>{
            return response;
        }));
    }

    
    public isProductExists(productName : string) : Promise<any>{
        return this.get(environment.base_path+"assets/data/inventory.json").toPromise();           
    }

    
    public CheckProductExists(productName : string) : Observable<any>{
        return this.get(environment.api_path+"products/"+productName).pipe(map((response)=>{
            return response;
        }));    
    }

}