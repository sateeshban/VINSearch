import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { InventoryService } from '../services/product.service';
import { Supplier } from '../models/supplier';

@Component({
  selector: 'app-add-supplier',
  templateUrl: './add-supplier.component.html',
  styleUrls: ['./add-supplier.component.css']
})
export class AddSupplierComponent implements OnInit {

  @ViewChild('f') ngForm : any;
  supplierMdl: Supplier;
  isSupplierExist: boolean;
  
  constructor(private router: Router, private inventService: InventoryService) 
  { 
    this.supplierMdl = new Supplier();
  }

  ngOnInit() {
    
  }

  onSubmit() {debugger;
    this.supplierMdl.SupplierId = this.supplierMdl.SupplierId == null ? 0:this.supplierMdl.SupplierId;
    let modelData = this.supplierMdl;
    this.inventService.AddNewSupplier(modelData).subscribe((resp: any) => {
      if (resp != null && resp.newSupplierId > 0) {
        this.router.navigate(["inventories"]);
      }
    });
  }

  CheckSupplierExists(suppName: string): void {
    this.inventService.CheckSupplierExists(suppName).subscribe((resp: any) => {
      if (resp != null) {
        this.isSupplierExist = resp.isSupplierExist;
      }
    });
  }

  clearForm(){
    this.router.navigate(["inventories"]);
  }

}
