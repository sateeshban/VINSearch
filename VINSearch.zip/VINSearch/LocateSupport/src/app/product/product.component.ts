import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router'
import { NgbModal,NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Inventory } from '../models/Inventory';
import { DialogModel } from '../models/dialogModel';
import { DataTableResponse } from '../models/dataTableResponse';
import { InventoryService } from '../services/product.service';
import { Http } from '@angular/http';
import { BaseService } from '../services/base.service';
import { CommonModalComponent } from '../common/modal/common.modal.component';
import { ModalService } from '../services/ModalService';
import { Observable,from } from 'rxjs';
import { LoginService } from '../login/login.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css'],
  providers : [InventoryService]
})
export class ProductComponent implements OnInit {

  productList : Array<Inventory>;
  isHavingEmptyRecords : boolean = false;

  constructor(
    private modalService: ModalService, 
    private router: Router,
    private inventoryService: InventoryService,
    private currentModal: NgbActiveModal, 
    private loginService: LoginService) {   }

  ngOnInit() {
    this.productList=[];
    this.getInventories(true);
  }

  /* ORIGINAL METHOD */
  // getInventories(): void {
  //   this.inventoryService.getInventories().subscribe((response : any) => {
  //     debugger;
  //      this.productList = response;
  //      if(response.length == 0){
  //        this.isHavingEmptyRecords = true;
  //      }
  //   });
  // }
  getInventories(isActives: boolean): void {
    // this.inventoryService.getInventories(isActives).subscribe((response : any) => {
    //    this.productList = response;
    //    if(response.length == 0){
    //      this.isHavingEmptyRecords = true;
    //    }
    // });
  }

  goToAddInventory() : void{
    this.router.navigate(['inventory']);
  }
  goToAddSupplier():void{
    this.router.navigate(["supplier"]);
  }

  editProduct(productId: number): void{
    debugger;
    this.router.navigate(["/inventory",{"productId":productId}]);
  }

  deleteConfirmation(product: number,productName : string) : void {
    let dialogModel=new DialogModel();
    dialogModel.body = `Are you sure want to delete the product:- ${productName}`;
    dialogModel.title = "Confirmation Dialog";
    dialogModel.btnOkText ="Ok";
    dialogModel.btnCancelText="Cancel";
    dialogModel.isCancelEnabled = true;
    from(this.modalService.confirmDialog(dialogModel)).subscribe((res)=>{
      if(res){
        this.deleteProduct(product);
      }
      this.currentModal.close(true);
    });
  }

  deleteProduct(product: number):void{
    this.inventoryService.deleteInventory(product).subscribe((response:any)=> {
     if(response!=null){
       this.getInventories(true);
     }
    });
  }
  onCheckBoxChanged($event):void{
    this.getInventories($event.target.checked);
  }

  SignOut() {
    this.loginService.authSignOut();
  }

}
