export class user {
    tokens : any[];
    firstname : string;
    lastname : string;
    company : string;
    department:string;
    cdsid:string;
    removeId:boolean;
}